import Sidebar from "./Sidebar";
import "./Admin.css";

const Admin = () => {
  return (
    <div>
      <div className="admin-div">
        <Sidebar />
      </div>
    </div>
  );
};

export default Admin;
